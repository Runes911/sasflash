SAS3FLASH: GCA Release: FLASH_MPT_GEN3_Phase15.0 - 16.00.00.00
Release Version: 16.00.00.00
Release Date: 04-MAY-17
OS supported: DOS, UEFI x64/ARM, Windows x86/x64, Linux x86/x64/PPC64/ARM, Solaris x86/SPARC
Release Note: FLASH_MPT_GEN3_Phase15.0-16.00.00.00.pdf